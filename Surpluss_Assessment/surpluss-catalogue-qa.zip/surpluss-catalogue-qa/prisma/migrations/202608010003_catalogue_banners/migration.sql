ALTER TABLE "catalogues" ADD COLUMN "banners" JSONB NOT NULL DEFAULT '[]';
